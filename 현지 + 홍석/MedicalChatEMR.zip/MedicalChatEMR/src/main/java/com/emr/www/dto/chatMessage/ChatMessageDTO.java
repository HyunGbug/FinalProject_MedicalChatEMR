package com.emr.www.dto.chatMessage;


public class ChatMessageDTO {

}
